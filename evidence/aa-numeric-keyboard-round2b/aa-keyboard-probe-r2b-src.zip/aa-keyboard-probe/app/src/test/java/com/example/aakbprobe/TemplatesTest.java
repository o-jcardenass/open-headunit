package com.example.aakbprobe;

import android.content.Context;

import androidx.car.app.model.signin.InputSignInMethod;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;

/**
 * Every template the probe can show, built for real.
 *
 * The car.app builders enforce their action constraints at runtime, so a violation compiles
 * cleanly and only crashes in onGetTemplate on the head unit. Round 2 was lost to two of them.
 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class TemplatesTest {

    private Context context() {
        return RuntimeEnvironment.getApplication();
    }

    @Test
    public void everyKeyboardTypeBuilds() {
        int[] types = {
                InputSignInMethod.KEYBOARD_NUMBER,
                InputSignInMethod.KEYBOARD_DEFAULT,
                InputSignInMethod.KEYBOARD_PHONE,
                InputSignInMethod.KEYBOARD_EMAIL,
        };
        for (int type : types) {
            Templates.keyboard(context(), type, "row", () -> { }, text -> { });
        }
    }

    @Test
    public void keypadBuilds() {
        Templates.keypad(context(), "123", text -> { }, phoneNumber -> { });
    }
}
