package com.example.aakbprobe;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.car.app.dialer.TelephoneKeypadTemplate;
import androidx.car.app.model.Action;
import androidx.car.app.model.CarIcon;
import androidx.car.app.model.CarText;
import androidx.car.app.model.Header;
import androidx.car.app.model.InputCallback;
import androidx.car.app.model.ParkedOnlyOnClickListener;
import androidx.car.app.model.Template;
import androidx.car.app.model.signin.InputSignInMethod;
import androidx.car.app.model.signin.SignInTemplate;
import androidx.core.graphics.drawable.IconCompat;

/**
 * Every template the probe builds, as plain static factories.
 *
 * The car.app builders enforce their action constraints at runtime, so a violation compiles and
 * then crashes on the head unit. Building them here lets MainActivity prove they construct before
 * anyone drives to the rig.
 */
final class Templates {

    /** Java 8 Consumer needs desugaring at this minSdk; this is the one line of it we want. */
    interface TextSink {
        void accept(@NonNull String text);
    }

    private Templates() {
    }

    static Template keyboard(@NonNull Context context, int keyboardType, @NonNull String label,
            @NonNull Runnable back, @NonNull TextSink onSubmit) {
        InputCallback callback = new InputCallback() {
            @Override
            public void onInputSubmitted(@NonNull String text) {
                onSubmit.accept(text);
            }
        };

        // setShowKeyboardByDefault so the keyboard is on screen without a tap, which keeps the
        // screenshot free of any interaction that could be blamed for the result.
        InputSignInMethod input = new InputSignInMethod.Builder(callback)
                .setHint("Liters")
                .setKeyboardType(keyboardType)
                .setShowKeyboardByDefault(true)
                .build();

        // setHeaderAction and ActionStrip are not drawn on this host, and the projection swallows
        // hardware BACK, so the only usable way back is an action in the template body. That action
        // must carry a ParkedOnlyOnClickListener or SignInTemplate throws.
        return new SignInTemplate.Builder(input)
                .setTitle(label)
                .setInstructions("setKeyboardType(" + keyboardType + ")")
                .setHeaderAction(Action.BACK)
                .addAction(new Action.Builder()
                        .setTitle("Back to list")
                        .setOnClickListener(ParkedOnlyOnClickListener.create(back::run))
                        .build())
                .build();
    }

    static Template keypad(@NonNull Context context, @NonNull String digits,
            @NonNull TextSink onSave,
            @NonNull TelephoneKeypadTemplate.PhoneNumberChangeListener onChange) {
        // ACTION_CONSTRAINTS_TELEPHONE_KEYPAD_PRIMARY is maxCustomTitles=0 requireActionIcons=true,
        // so the primary action has to be an icon with no title.
        Action primary = new Action.Builder()
                .setIcon(new CarIcon.Builder(IconCompat.createWithResource(
                        context, R.drawable.ic_probe_save)).build())
                .setOnClickListener(() -> onSave.accept(digits))
                .build();

        return new TelephoneKeypadTemplate.Builder(primary, onChange)
                .setHeader(new Header.Builder()
                        .setTitle("E  TelephoneKeypadTemplate")
                        .setStartHeaderAction(Action.BACK)
                        .build())
                .setPhoneNumber(digits)
                // Does * survive as a stand-in decimal separator? There is no decimal key.
                .addKeySecondaryText(TelephoneKeypadTemplate.KEY_STAR, CarText.create("dec?"))
                .build();
    }
}
