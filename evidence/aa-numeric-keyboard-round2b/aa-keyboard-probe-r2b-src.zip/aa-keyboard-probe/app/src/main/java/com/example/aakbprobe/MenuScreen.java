package com.example.aakbprobe;

import androidx.annotation.NonNull;
import androidx.car.app.CarContext;
import androidx.car.app.Screen;
import androidx.car.app.model.Action;
import androidx.car.app.model.ItemList;
import androidx.car.app.model.ListTemplate;
import androidx.car.app.model.Row;
import androidx.car.app.model.Template;
import androidx.car.app.model.signin.InputSignInMethod;

/**
 * Four entries into the same screen. The only difference between them is the int handed to
 * setKeyboardType, so anything that differs on screen is attributable to that constant alone.
 */
public class MenuScreen extends Screen {

    MenuScreen(@NonNull CarContext carContext) {
        super(carContext);
    }

    @NonNull
    @Override
    public Template onGetTemplate() {
        ItemList list = new ItemList.Builder()
                .addItem(row("A  KEYBOARD_NUMBER", "expect a numeric keypad",
                        InputSignInMethod.KEYBOARD_NUMBER))
                .addItem(row("B  KEYBOARD_DEFAULT", "expect the full QWERTY",
                        InputSignInMethod.KEYBOARD_DEFAULT))
                .addItem(row("C  KEYBOARD_PHONE", "expect a dialpad",
                        InputSignInMethod.KEYBOARD_PHONE))
                .addItem(row("D  KEYBOARD_EMAIL", "expect QWERTY with an @ key",
                        InputSignInMethod.KEYBOARD_EMAIL))
                .addItem(new Row.Builder()
                        .setTitle("E  TelephoneKeypadTemplate")
                        .addText("a keypad drawn by the template, not the keyboard")
                        .setBrowsable(true)
                        .setOnClickListener(() -> getScreenManager()
                                .push(new KeypadScreen(getCarContext())))
                        .build())
                .build();

        return new ListTemplate.Builder()
                .setSingleList(list)
                .setTitle("AA keyboard probe")
                .setHeaderAction(Action.APP_ICON)
                .build();
    }

    private Row row(String title, String expectation, int keyboardType) {
        return new Row.Builder()
                .setTitle(title)
                .addText(expectation)
                .setBrowsable(true)
                .setOnClickListener(() -> getScreenManager()
                        .push(new KeyboardScreen(getCarContext(), keyboardType, title)))
                .build();
    }
}
