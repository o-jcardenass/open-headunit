package com.example.aakbprobe;

import androidx.annotation.NonNull;
import androidx.car.app.CarContext;
import androidx.car.app.CarToast;
import androidx.car.app.Screen;
import androidx.car.app.model.Template;

/** A SignInTemplate whose only variable is the keyboard type. */
public class KeyboardScreen extends Screen {

    private final int mKeyboardType;
    private final String mLabel;

    KeyboardScreen(@NonNull CarContext carContext, int keyboardType, @NonNull String label) {
        super(carContext);
        mKeyboardType = keyboardType;
        mLabel = label;
    }

    @NonNull
    @Override
    public Template onGetTemplate() {
        return Templates.keyboard(
                getCarContext(),
                mKeyboardType,
                mLabel,
                () -> getScreenManager().pop(),
                text -> CarToast
                        .makeText(getCarContext(), "submitted: " + text, CarToast.LENGTH_LONG)
                        .show());
    }
}
