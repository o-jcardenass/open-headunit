package com.example.aakbprobe;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.car.app.model.signin.InputSignInMethod;

/**
 * Phone-side placeholder, plus a pre-flight check.
 *
 * The car.app builders validate their action constraints at runtime, so a violation compiles
 * cleanly and then crashes in onGetTemplate on the head unit. Round 2 was lost that way. Building
 * every template here means the failure shows up on the bench, before the rig.
 */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setPadding(48, 96, 48, 48);
        tv.setTextSize(16f);
        tv.setText("AA keyboard probe\n\n"
                + "Open \"AA KB Probe\" on the head unit, not here.\n\n"
                + "Android Auto must have developer mode on and "
                + "Settings > Developer settings > Unknown sources enabled, "
                + "or an unpublished template app is not listed.\n\n"
                + "Pre-flight (every template this probe can show):\n\n"
                + preflight());
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        setContentView(sv);
    }

    private String preflight() {
        StringBuilder sb = new StringBuilder();
        int[] types = {
                InputSignInMethod.KEYBOARD_NUMBER,
                InputSignInMethod.KEYBOARD_DEFAULT,
                InputSignInMethod.KEYBOARD_PHONE,
                InputSignInMethod.KEYBOARD_EMAIL,
        };
        String[] rows = {"A KEYBOARD_NUMBER", "B KEYBOARD_DEFAULT", "C KEYBOARD_PHONE",
                "D KEYBOARD_EMAIL"};
        for (int i = 0; i < types.length; i++) {
            final int type = types[i];
            final String row = rows[i];
            sb.append(check(row, () -> Templates.keyboard(
                    this, type, row, () -> { }, text -> { })));
        }
        sb.append(check("E TelephoneKeypadTemplate", () -> Templates.keypad(
                this, "", text -> { }, phoneNumber -> { })));
        return sb.toString();
    }

    private String check(String label, Runnable build) {
        try {
            build.run();
            return "OK    " + label + "\n";
        } catch (Throwable t) {
            return "FAIL  " + label + "\n      " + t + "\n";
        }
    }
}
