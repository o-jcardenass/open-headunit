package com.example.aakbprobe;

import androidx.annotation.NonNull;
import androidx.car.app.CarContext;
import androidx.car.app.CarToast;
import androidx.car.app.Screen;
import androidx.car.app.model.Template;

/**
 * The keypad is drawn by the template itself, so it does not go through the car keyboard at all.
 * That is the whole point: the touch keyboard picks its layout by locale and never reads inputType.
 */
public class KeypadScreen extends Screen {

    private String mDigits = "";

    KeypadScreen(@NonNull CarContext carContext) {
        super(carContext);
    }

    @NonNull
    @Override
    public Template onGetTemplate() {
        return Templates.keypad(
                getCarContext(),
                mDigits,
                text -> CarToast
                        .makeText(getCarContext(), "entered: " + text, CarToast.LENGTH_LONG)
                        .show(),
                phoneNumber -> {
                    mDigits = phoneNumber;
                    invalidate();
                });
    }
}
