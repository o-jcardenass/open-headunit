package com.example.aakbprobe;

import androidx.annotation.NonNull;
import androidx.car.app.CarContext;
import androidx.car.app.CarToast;
import androidx.car.app.Screen;
import androidx.car.app.model.Action;
import androidx.car.app.model.InputCallback;
import androidx.car.app.model.Template;
import androidx.car.app.model.signin.InputSignInMethod;
import androidx.car.app.model.signin.SignInTemplate;

/** A SignInTemplate whose only variable is the keyboard type. */
public class KeyboardScreen extends Screen {

    private final int mKeyboardType;
    private final String mLabel;

    KeyboardScreen(@NonNull CarContext carContext, int keyboardType, @NonNull String label) {
        super(carContext);
        mKeyboardType = keyboardType;
        mLabel = label;
    }

    @NonNull
    @Override
    public Template onGetTemplate() {
        InputCallback callback = new InputCallback() {
            @Override
            public void onInputSubmitted(@NonNull String text) {
                CarToast.makeText(getCarContext(), "submitted: " + text, CarToast.LENGTH_LONG)
                        .show();
            }
        };

        // setShowKeyboardByDefault so the keyboard is on screen without a tap, which keeps the
        // screenshot free of any interaction that could be blamed for the result.
        InputSignInMethod input = new InputSignInMethod.Builder(callback)
                .setHint("Liters")
                .setKeyboardType(mKeyboardType)
                .setShowKeyboardByDefault(true)
                .build();

        return new SignInTemplate.Builder(input)
                .setTitle(mLabel)
                .setInstructions("setKeyboardType(" + mKeyboardType + ")")
                .setHeaderAction(Action.BACK)
                .build();
    }
}
