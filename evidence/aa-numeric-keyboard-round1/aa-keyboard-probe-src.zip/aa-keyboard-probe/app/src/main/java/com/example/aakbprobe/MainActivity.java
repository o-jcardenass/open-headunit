package com.example.aakbprobe;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/** Phone-side placeholder. The probe itself only ever runs on the head unit. */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setPadding(48, 96, 48, 48);
        tv.setTextSize(16f);
        tv.setText("AA keyboard probe\n\n"
                + "Open \"AA KB Probe\" on the head unit, not here.\n\n"
                + "Android Auto must have developer mode on and "
                + "Settings > Developer settings > Unknown sources enabled, "
                + "or an unpublished template app is not listed.");
        setContentView(tv);
    }
}
