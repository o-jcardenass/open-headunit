package com.example.aakbprobe;

import androidx.annotation.NonNull;
import androidx.car.app.CarContext;
import androidx.car.app.CarToast;
import androidx.car.app.Screen;
import androidx.car.app.dialer.TelephoneKeypadTemplate;
import androidx.car.app.model.Action;
import androidx.car.app.model.CarText;
import androidx.car.app.model.Header;
import androidx.car.app.model.Template;

/**
 * The keypad is drawn by the template itself, so it does not go through the car keyboard at all.
 * That is the whole point: the touch keyboard picks its layout by locale and never reads inputType.
 */
public class KeypadScreen extends Screen {

    private String mDigits = "";

    KeypadScreen(@NonNull CarContext carContext) {
        super(carContext);
    }

    @NonNull
    @Override
    public Template onGetTemplate() {
        Action primary = new Action.Builder()
                .setTitle("Save")
                .setOnClickListener(() -> CarToast
                        .makeText(getCarContext(), "entered: " + mDigits, CarToast.LENGTH_LONG)
                        .show())
                .build();

        TelephoneKeypadTemplate.Builder builder =
                new TelephoneKeypadTemplate.Builder(primary, phoneNumber -> {
                    mDigits = phoneNumber;
                    invalidate();
                })
                        .setHeader(new Header.Builder()
                                .setTitle("E  TelephoneKeypadTemplate")
                                .setStartHeaderAction(Action.BACK)
                                .build())
                        .setPhoneNumber(mDigits);

        // Does * survive as a stand-in decimal separator? There is no decimal key.
        builder.addKeySecondaryText(TelephoneKeypadTemplate.KEY_STAR, CarText.create("dec?"));
        return builder.build();
    }
}
